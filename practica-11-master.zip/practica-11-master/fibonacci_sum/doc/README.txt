Directory for Doxygen documentation, if generated
